import logging
from aiogram import Bot, Dispatcher, executor, types
import os

logging.basicConfig(level=logging.INFO)

TOKEN = os.getenv("TOKEN")  # Бот токен должен быть в переменных окружения
bot = Bot(token=TOKEN)
dp = Dispatcher(bot)

@dp.message_handler(commands=["start", "help"])
async def send_welcome(message: types.Message):
    await message.reply("Привет! Я работаю 24/7 на Render!")

if __name__ == "__main__":
    executor.start_polling(dp, skip_updates=True)
